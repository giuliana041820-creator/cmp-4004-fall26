# Results status

`per_instance.csv` currently contains only the arm-A (hand model) run and `validation.txt` the independent dataset check.
Arms B, B′ and C have NOT been run yet (no model credentials were available when this package was prepared).
Running `python code/run_experiment.py` then `python code/analyze.py` overwrites this folder with the full results
(`scorecard.csv`, `accuracy_by_difficulty.csv`, `taxonomy_counts.csv`, `refinement.csv`, `cost.csv`, `run_meta.json`),
regenerates `taxonomy.md`, `fig/*.png` and `REPORT.md`.
